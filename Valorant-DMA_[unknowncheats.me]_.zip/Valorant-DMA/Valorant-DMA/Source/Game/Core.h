#pragma once
#include "structs.hpp"

class Core
{
public:
	void InitGame(bool debug = true);
};

inline Core InitCore;