Default vmmdll.lib, leechcore.lib and FTD3XX.lib

Might have to update meticks lib.